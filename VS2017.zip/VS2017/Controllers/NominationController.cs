﻿using ang.web.Models;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web.Http;

namespace ang.web.Controllers
{
    [RoutePrefix("api/nomination")]
    public class NominationController : ApiController
    {
        private Repository repository;
        private const string connectionName = "mongoDb.connection";
        public NominationController()
        {
             repository = new Repository(ConfigurationManager.AppSettings[connectionName]);
        }

        [HttpGet]
        public IHttpActionResult Get(string id)
        {
            List<Nomination> nominations = new List<Nomination> {
                new Nomination() {
                    SprintName ="19",
                    Comments ="asdfasf",
                    TeamMember ="aaa",
                    TeamName ="asdsaf",
                    VoterName ="asdasf" }
            };
            return Ok(nominations);
        }

        [HttpPost]
        public IHttpActionResult Post([FromBody]Nomination vote)
        {
            try
            {
                repository.Save(vote);
                return Ok();
            }
            catch
            {
                return BadRequest();
            }
        }
    }


    public class Repository
    {
        private MongoClient MongodbClient;
        private IMongoDatabase Mongodb;
        private IMongoCollection<BsonDocument> votingDocument;
        public Repository(string connectionString)
        {
            MongodbClient = new MongoClient(connectionString);
            Mongodb = MongodbClient.GetDatabase("voting");
            votingDocument = Mongodb.GetCollection<BsonDocument>("nominations");
        }

        
        public void Save(Nomination nomination)
        {
            
            BsonDocument newNomination = new BsonDocument();
            BsonElement sprintName = new BsonElement("sprintname",nomination.SprintName);
            newNomination.Add(sprintName);
            BsonElement teamName = new BsonElement("teamname", nomination.TeamName);
            newNomination.Add(teamName);
            BsonElement voteFor = new BsonElement("teammemeber", nomination.TeamMember);
            newNomination.Add(voteFor);
            BsonElement voter = new BsonElement("votername", nomination.VoterName);
            newNomination.Add(voter);
            BsonElement comments = new BsonElement("comments", nomination.Comments);
            newNomination.Add(comments);
            votingDocument.InsertOne(newNomination);
 
        }
    }

    class DB
    {
        static void Connect()
        {
            try
            {
                MongoClient MongodbClient = new MongoClient("mongodb://127.0.0.1:27017");
                // Get Database and Collection
                IMongoDatabase Mongodb = MongodbClient.GetDatabase("MyDatabase");
                var MongodbcollList = Mongodb.ListCollections().ToList();
                Console.WriteLine("The MongoDB list of collectionsare: ");
                foreach (var item in MongodbcollList)
                {
                    Console.WriteLine(item);
                }
                var mydocument = Mongodb.GetCollection<BsonDocument>("mydocument");

                create(Mongodb, mydocument);
                update(Mongodb, mydocument);
                delete(Mongodb, mydocument);

                var myresultDoc = mydocument.Find(new
                   BsonDocument()).ToList();
                foreach (var myitem in myresultDoc)
                {
                    Console.WriteLine(myitem.ToString());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadLine();
        }
        private static void create(IMongoDatabase mongodb, IMongoCollection<BsonDocument> mydocument)
        {
            BsonElement employeename = new BsonElement("employeename",
               "Tapas Pal");
            BsonDocument empployee = new BsonDocument();
            empployee.Add(employeename);
            empployee.Add(new BsonElement("employeenumber", 123));
            mydocument.InsertOne(empployee);

        }
        private static void update(IMongoDatabase mongodb, IMongoCollection<BsonDocument> mydocument)
        {
            // UPDATE
            BsonElement updateemployee = new
               BsonElement("employeename", "Tapas1 Pal1");

            BsonDocument updateemployeedoc = new BsonDocument();
            updateemployeedoc.Add(updateemployee);
            updateemployeedoc.Add(new BsonElement("employeenumber",
               1234));

            BsonDocument findemployeeDoc = new BsonDocument(new
               BsonElement("employeename", "Tapas Pal"));

            var updateDoc = mydocument.FindOneAndReplace
               (findemployeeDoc, updateemployeedoc);

            Console.WriteLine(updateDoc);

        }
        private static void delete(IMongoDatabase mongodb, IMongoCollection<BsonDocument> mydocument)
        {
            // DELETE
            BsonDocument findAnotheremployee = new BsonDocument(new
               BsonElement("employeename", "Tapas1 Pal1"));

            mydocument.FindOneAndDelete(findAnotheremployee);
        }
    }
}
