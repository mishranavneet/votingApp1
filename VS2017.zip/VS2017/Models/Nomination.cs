﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ang.web.Models
{
    public class Nomination
    {
        public string VoterName { get; set; }
        public string SprintName { get; set; }
        public string TeamName { get; set; }
        public string TeamMember { get; set; }
        public string Comments { get; set; }
    }
}