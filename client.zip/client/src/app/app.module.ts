import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { MemberListComponent } from './member-list/member-list.component';
import { CommonService } from './services/common.service';
import { ReportComponent } from './report/report.component';
import { ApiService } from './services/api.service';
import { DataShareService } from './services/data-share.service';


@NgModule({
  declarations: [
    AppComponent,
    MemberListComponent,
    ReportComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot( [
      { path: 'Home/Index' , component: MemberListComponent, pathMatch: 'full'},
      { path: '' , component: MemberListComponent, pathMatch: 'full'},
      { path: 'reports', component: ReportComponent }
    ])
  ],
  providers: [ CommonService, ApiService, DataShareService],
  bootstrap: [AppComponent]
})
export class AppModule { }
