import { Component, ElementRef } from '@angular/core';
import { DataShareService } from './services/data-share.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  currentUser: string;
  constructor(private eltRef: ElementRef,
              private dataShareService: DataShareService) {
    this.currentUser = eltRef.nativeElement.getAttribute('currentUser');
    this.dataShareService.updateUserName(this.currentUser);
  }
}
