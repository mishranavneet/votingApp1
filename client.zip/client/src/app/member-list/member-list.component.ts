import { Component, OnInit, Input } from '@angular/core';
import { CommonService } from '../services/common.service';
import { Observable, of } from 'rxjs';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ApiService } from '../services/api.service';
import { Nomination } from '../models/model';
import { DataShareService } from '../services/data-share.service';

@Component({
  selector: 'app-member-list',
  templateUrl: './member-list.component.html',
  styleUrls: ['./member-list.component.css']
})
export class MemberListComponent implements OnInit {

  sprintNames: string[];
  teamNames: string[];
  teamMembers$: Observable<string[]>;
  formVote: FormGroup;
  user: string;
  success$: Observable<boolean>;
  error$: Observable<boolean>;

  constructor(private commonService: CommonService,
              private apiService: ApiService,
              private dataShareService: DataShareService,
              private fb: FormBuilder) {
  }

  ngOnInit() {
    this.createForm();
    this.sprintNames = this.commonService.getSprintNames();
    this.teamNames = this.commonService.getSprintTeam();
    this.teamMembers$ = of(['--select team first --']);
    this.dataShareService.currentUser.subscribe(currentUser => this.user = currentUser);
    this.success$ = of(false);
    this.error$ = of(false);
  }

  createForm() {
    this.formVote = this.fb.group( {
      sprintNameCtrl: '',
      teamNameCtrl: '',
      voteForCtrl: '',
      commentsCtrl: ''
    });
  }

  onSelectChange(team) {
    this.teamMembers$ = of(this.commonService.getTeamMember(team));
  }

  sendNomination() {
    const nomination: Nomination = {
       voterName: this.user,
       SprintName: this.formVote.controls.sprintNameCtrl.value,
       TeamMember: this.formVote.controls.voteForCtrl.value,
       TeamName: this.formVote.controls.teamNameCtrl.value,
       Comments: this.formVote.controls.commentsCtrl.value
    };
    this.apiService.saveNomination(nomination)
    .subscribe(
      data => this.success$ = of(true),
      err => this.error$ = of(true)
    );

  }
}
