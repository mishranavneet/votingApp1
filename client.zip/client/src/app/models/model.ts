export class Nomination {
    voterName: string;
    SprintName: string;
    TeamName: string;
    TeamMember: string;
    Comments: string;
}
