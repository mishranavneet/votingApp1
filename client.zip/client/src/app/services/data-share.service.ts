import { Injectable } from '@angular/core';
import { Subject, BehaviorSubject } from 'rxjs';

@Injectable()
export class DataShareService {
    private source = new BehaviorSubject('');
    currentUser = this.source.asObservable();
    constructor() {}
    updateUserName(user: string) {
        this.source.next(user);
    }
}
