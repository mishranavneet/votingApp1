import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Nomination } from '../models/model';

@Injectable()
export class ApiService {
    constructor(private httpClient: HttpClient) {}

    saveNomination(vote: Nomination) {
        return this.httpClient.post('api/nomination', vote);
    }

    getNominations(sprintName: string) {
        return this.httpClient.get('api/nomination/19');
    }

    private getRequestHeaders() {

    }
}
