import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable()
export class CommonService {

    getSprintNames(): string[] {
        const values: string[] = [ '--select--', '19', '20', '21', '22' ];
        return values;
    }

    getSprintTeam(): string[] {
        const values: string[] = [ '--select--', 'Topaz', 'Blue Topaz' ];
        return values;
    }

    getTeamMember(team): string[] {
        const values: string[] = team === 'Topaz' ?
         [ '--select--', 'Sandeep', 'Vanaja'] : [ '--select--', 'Navneet Mishra', 'Ankur Bhojk'];
        return values;
    }
}
