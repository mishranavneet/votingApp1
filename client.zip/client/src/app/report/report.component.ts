import { Component, OnInit } from '@angular/core';
import { CommonService } from '../services/common.service';
import { Observable, of } from 'rxjs';
import { Nomination } from '../models/model';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {
  sprintNames: string[];
  nominations$: Observable<Nomination[]>;
  error: any;
  constructor(private commonService: CommonService,
              private apiService: ApiService) { }

  ngOnInit() {
    this.sprintNames = this.commonService.getSprintNames();
  }

  onSelectChange(sprintName) {
    this.apiService.getNominations(sprintName)
    .subscribe(
      data => this.nominations$ = of(<Nomination[]>data),
      err => this.error = err
    );
  }

}
